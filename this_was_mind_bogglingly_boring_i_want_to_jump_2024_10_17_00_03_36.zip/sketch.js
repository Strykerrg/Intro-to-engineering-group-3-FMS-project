let circleX, circleY, circleSpeedX;
let rectX, rectY, rectSpeedY;

function setup() {
  createCanvas(800, 400);
  
  // Initialize circle properties
  circleX = 100;
  circleY = height / 2;
  circleSpeedX = 2;
  
  // Initialize rectangle properties
  rectX = 300;
  rectY = 100;
  rectSpeedY = 3;
}

function draw() {
  background(255);
  
  // Draw the circle (blue with a thick outline)
  stroke(0, 0, 255);
  strokeWeight(4);
  fill(0, 100, 255);
  ellipse(circleX, circleY, 50);
  
  // Draw the rectangle (red with a dashed outline)
  stroke(255, 0, 0);
  strokeWeight(2);
  drawingContext.setLineDash([5, 5]);
  rect(rectX, rectY, 100, 50);
  drawingContext.setLineDash([]); // Reset dash
  
  // Draw the triangle (green with a thin outline)
  stroke(0, 255, 0);
  strokeWeight(1);
  fill(0, 255, 100);
  triangle(600, 300, 550, 350, 650, 350);
  
  // Move the circle
  circleX += circleSpeedX;
  
  // Change direction if the circle hits the edge
  if (circleX > width - 25 || circleX < 25) {
    circleSpeedX *= -1; // Reverse direction
  }
  
  // Move the rectangle
  rectY += rectSpeedY;
  
  // Change direction if the rectangle hits the edge
  if (rectY > height - 25 || rectY < 25) {
    rectSpeedY *= -1; // Reverse direction
  }
}
